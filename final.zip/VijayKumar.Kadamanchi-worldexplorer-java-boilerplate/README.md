# WorldExplorer
## Problem Statement
Build a system to search for country and list matching countries, show details of a
selected country and bookmark favourite country.
## Requirements
- ​ The application needs to fetch country details by using the following API link.
https://restcountries.eu/
Sample reference APIs:
https://restcountries.eu/rest/v2/all
https://restcountries.eu/rest/v2/name/india
- A frontend web app where the user can register/login to the application, search for country,
view details about selected country and add country to favourite list.
- User can add country into favourite list and should be able to view the favourite countries for
user.
## Modules
### UserService - should be able to manage user accounts.
### WorldExplorerUI (User interface) - should be able to
1. Search for country and show list of matching countries
2. View details of a selected country
3. Add a country to favourite list
4. should be able to see favourite list of countries
5. UI should be responsive which can run smoothly on various devices
### FavouriteService - should be able to store all the favourite countries for a user
## Tech Stack
- Spring Boot
- Angular
- CI (Gitlab Runner)
- Docker, Docker Compose
## Flow of Modules
### Building frontend
- Building responsive views:1. Register/Login
2. Search for country and show list of matching countries - populating from external API
3. Show details of selected country - populating from external API
4. Build a view to add and show favourite countries
- Using Services to populate these data in views
- Stitching these views using Routes and Guards
- Making the UI Responsive
- E2E test cases and unit test cases
- Writing CI configuration file
- Dockerize the frontend
### Building the UserService
- Creating a server in Spring Boot to facilitate user registration and login using JWT token and
MySQL
- Writing swagger documentation
- Unit Testing
- Write CI Configuration
- Dockerize the application
- Write docker-compose file to build both frontend and backend application
### Building the Favourite Service
- Building a server in Spring Boot to facilitate CRUD operation over favourite countries stored in
MySQL
- Writing Swagger Documentation
- Write Test Cases
- Write CI Configuration
- Dockerize the application
- Update the docker-compose
### Demonstrate the entire application
