import { AppPage } from './app.po';
import { browser, by, protractor, element } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('WorldExplorerUI');
  });

  it('should be redirected to /login route on opening the application',()=>{
    expect(browser.getCurrentUrl()).toContain('/login')
  });

  it('should be redirected to /register route',() => {
    browser.element(by.css('.register-button')).click()
    expect(browser.getCurrentUrl()).toContain('/register')
  });

  it('should be able to register user',() =>{
    browser.element(by.id('firstName')).sendKeys('Super user');
    browser.element(by.id('lastName')).sendKeys('Super lastuser');
    browser.element(by.id('userId')).sendKeys('Super user12');
    browser.element(by.id('password')).sendKeys('Super userpass');
    browser.element(by.css('.register-user')).click()
    expect(browser.getCurrentUrl()).toContain('/login')
  });

  it('should be able to login user and navigate to all countries',()=>{
    browser.element(by.id('userId')).sendKeys('Super user12');
    browser.element(by.id('password')).sendKeys('Super userpass');
    browser.element(by.css('.login-user')).click()
    expect(browser.getCurrentUrl()).toContain('/countries/allcountries')
  });

  it('should be able to search for countries',()=>{
    browser.element(by.css('.search-button')).click()
    expect(browser.getCurrentUrl()).toContain('/countries/search')
    browser.element(by.id('search-button-input')).sendKeys('India')
    browser.element(by.id('search-button-input')).sendKeys(protractor.Key.ENTER)

    const searchItems = element.all(by.css('.countryName'));
    expect(searchItems.count()).toBe(2);
    for(let i=0;i<1;i+=1){
      expect(searchItems.get(i).getText()).toContain('India');
    }
  });

  it('should be able to add country to favourites',async()=>{
    browser.driver.manage().window().maximize();
    browser.driver.sleep(1000);
    const searchItems = element.all(by.css('.country-thumbnail'));
    expect(searchItems.count()).toBe(2);
    searchItems.get(0).click();
	
  });


});
