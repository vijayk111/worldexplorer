import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { CountryModule } from './modules/country/country.module';
import { MatButtonModule,MatButton } from '@angular/material/button';
import { MatDialogModule} from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule,MatToolbar } from '@angular/material/toolbar';
import { AuthguardService } from './authGuard.service';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatSidenavModule} from '@angular/material/sidenav';
import { LayoutModule } from '@angular/cdk/layout';
import { MatIconModule, MatListModule } from '@angular/material';
import { AuthenticationModule } from './modules/authentication/authentication.module';

@NgModule({
  declarations: [
    AppComponent  
  ],
  imports: [
    BrowserModule, 
    MatButtonModule,
    MatDialogModule,
    FormsModule,
    RouterModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    AppRoutingModule,
    CountryModule,    
    FlexLayoutModule,
    MatSidenavModule,
    LayoutModule,
    MatIconModule,
    MatListModule,
    AuthenticationModule,    
  ],
  providers: [AuthguardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
