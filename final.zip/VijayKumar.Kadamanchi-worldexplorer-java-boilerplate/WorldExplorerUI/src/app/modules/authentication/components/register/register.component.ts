import { Component, OnInit } from '@angular/core';
import { User } from '../../user.model';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../authentication.service';
import { HttpErrorResponse } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'authentication-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  newUser:User;

  constructor(private router:Router,private authService:AuthenticationService,private snackbar:MatSnackBar) {
    this.newUser=new User();
   }

  ngOnInit() {
  }

  registerUser(){
   
    this.authService.registerUser(this.newUser).subscribe(
      (data)=>{
       console.log("successfully registered!");
        this.router.navigate(['/login']);
      },
    (error:HttpErrorResponse)=>{
      console.log(error);
      this.snackbar.open(error.error,'',{duration:2000});
    });
  }

  reset(){
    this.newUser=new User();
  }

}
