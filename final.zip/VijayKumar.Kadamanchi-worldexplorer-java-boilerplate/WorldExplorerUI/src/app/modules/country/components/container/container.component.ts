import { Component, OnInit, Input } from '@angular/core';
import { Country } from '../../country.model';
import { CountryService } from '../../country.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'country-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  @Input()
  countries:Array<Country>;

  @Input()
  inFavourites:boolean;

  constructor(private countryService:CountryService,private snackbar:MatSnackBar) { 
    this.countries=[];
  }

  ngOnInit() {

  }

  addFavourites(country){
    let message=`${country.name} add to favourites`;
    this.countryService.addCountryToFavourites(country).subscribe(
      (country)=>{
        this.snackbar.open(message,'',{duration:1000});
      },
    (error:HttpErrorResponse)=>{
      this.snackbar.open("Country already added to favorites",'',{duration:2000});
    });
  }

  deleteFavourites(country){
    let message=`${country.name} deleted from favourites`;
    for(var i=0;i<this.countries.length;i++){
      if(this.countries[i].name == country.name){
        this.countries.splice(i,1);
      }
    }

    this.countryService.deleteFromFavourites(country).subscribe(
      (country)=>{
        console.log("deleted");
        this.snackbar.open(message,'',{duration:1000});
      });

  }

}
