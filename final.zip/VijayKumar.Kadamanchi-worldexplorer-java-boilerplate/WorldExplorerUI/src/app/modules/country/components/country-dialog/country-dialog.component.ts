import { Component, OnInit, Inject } from '@angular/core';
import { Country } from '../../country.model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CountryService } from '../../country.service';

@Component({
  selector: 'country-country-dialog',
  templateUrl: './country-dialog.component.html',
  styleUrls: ['./country-dialog.component.css']
})
export class CountryDialogComponent implements OnInit {
  country:Country;
  comments:string;
  actionType:string;

  constructor(public snackbar:MatSnackBar,public dialogRef:MatDialogRef<CountryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any,private countryService:CountryService) { 
      this.comments=data.obj.comments;
      this.country=data.obj;
      this.actionType=data.actionType;
    }

  ngOnInit() {

    
  }
  onNoClick(){
    this.dialogRef.close();
  }

  updateComments(){
    console.log("comments: ",this.comments);
    this.country.comments=this.comments;
    this.dialogRef.close();
    this.countryService.updateComments(this.country).subscribe(
      (country)=>{
        this.snackbar.open("Country Updated Successfully",'',{duration:2000});
      });

}

}
