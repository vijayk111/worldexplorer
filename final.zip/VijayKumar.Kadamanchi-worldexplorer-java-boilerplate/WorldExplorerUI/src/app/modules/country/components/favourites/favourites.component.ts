import { Component, OnInit } from '@angular/core';
import { Country } from '../../country.model';
import { CountryService } from '../../country.service';

@Component({
  selector: 'country-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {
  countries:Array<Country>;
  inFavourites=true;

  constructor(private countryService:CountryService) {
    this.countries=[];
   }

  ngOnInit() {
    this.countryService.getCountriesFromFavourites().subscribe(
      (countries)=>{
        this.countries.push(...countries);
      });

  }

}
