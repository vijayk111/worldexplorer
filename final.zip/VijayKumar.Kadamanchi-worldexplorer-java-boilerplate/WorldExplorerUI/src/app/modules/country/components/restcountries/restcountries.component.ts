import { Component, OnInit } from '@angular/core';
import { Country } from '../../country.model';
import { CountryService } from '../../country.service';

@Component({
  selector: 'country-restcountries',
  templateUrl: './restcountries.component.html',
  styleUrls: ['./restcountries.component.css']
})
export class RestcountriesComponent implements OnInit {
  countries:Array<Country>;

  constructor(private countryService:CountryService) { 
    this.countries=[];
  }

  ngOnInit() {
    this.countryService.getCountries().subscribe(
      (countries)=>{
        this.countries.push(...countries);
      });
  }

}
