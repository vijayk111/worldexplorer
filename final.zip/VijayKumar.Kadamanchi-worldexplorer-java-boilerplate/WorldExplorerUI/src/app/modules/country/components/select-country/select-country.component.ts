import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Country } from '../../country.model';
import { CountryService } from '../../country.service';

@Component({
  selector: 'country-select-country',
  templateUrl: './select-country.component.html',
  styleUrls: ['./select-country.component.css']
})
export class SelectCountryComponent implements OnInit {
  countryName: string;
  country: Country;

  constructor(private route: ActivatedRoute, private countryService: CountryService) {
    this.countryName = "";
  }

  ngOnInit() {

    this.countryName = this.route.snapshot.params["name"];

    this.countryService.showDetails(this.countryName).subscribe(
      (country) => {
        this.country = country[0];
      });
  }





}
