import { Routes, RouterModule } from "@angular/router";
import { RestcountriesComponent } from './components/restcountries/restcountries.component';
import { AuthguardService } from '../../authGuard.service';
import { FavouritesComponent } from './components/favourites/favourites.component';
import { SearchComponent } from './components/search/search.component';
import { NgModule } from '@angular/core';
import { SelectCountryComponent } from './components/select-country/select-country.component';

const countryRoutes: Routes = [
    {
        path: 'countries', children: [
            { path: '', 
            redirectTo: '/countries/allcountries', 
            pathMatch: 'full', 
            canActivate: [AuthguardService] 
        },
            { path: 'allcountries', component: RestcountriesComponent, canActivate: [AuthguardService] },
            { path: 'favourites', component: FavouritesComponent, canActivate: [AuthguardService] },
            { path: 'search', component: SearchComponent, canActivate: [AuthguardService] },
            { path: 'selectedcountry/:name',component:SelectCountryComponent, canActivate:[AuthguardService]}
        ]
    }
];


@NgModule({
    imports: [
        RouterModule.forChild(countryRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class CountryRouterModule {

}
