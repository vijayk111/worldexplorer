import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Country } from './country.model';
import { AuthenticationService } from '../authentication/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  restCountryEndPoint:string;
  springEndPoint:string;

  constructor(private http:HttpClient,private authService:AuthenticationService) {
    this.restCountryEndPoint='https://restcountries.eu/rest/v2';
    this.springEndPoint='http://localhost:8080/rest/v2';
   }

   getCountries():Observable<Array<Country>>{
     return this.http.get(this.restCountryEndPoint+"/all").pipe(map(this.transformData.bind(this)));
   }

     transformData(countries):Array<Country>{
       return countries.map(country=> {
         let con:Country=new Country();
         con.name=country['name'];
         con.capital=country['capital'];
         con.region=country['region'];
         con.flag=country['flag'];
        return con;
       });

     }

    addCountryToFavourites(country){
      return this.http.post(this.springEndPoint+"/country",country,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
    }

    updateComments(country:Country){
      const url=`${this.springEndPoint}`;
      return this.http.put(url,country,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
     }

     deleteFromFavourites(country:Country){
      const url=`${this.springEndPoint}/${country.id}`;
      return this.http.delete(url,{responseType:"text"});
    }

    getCountriesFromFavourites():Observable<Array<Country>>{
      return this.http.get<Array<Country>>(this.springEndPoint,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
    }

    searchCountries(searchKey:string):Observable<Array<Country>>{
      if(searchKey.length>0){
        const url=`${this.restCountryEndPoint}/name/${searchKey}`;
        return this.http.get<Array<Country>>(url);  
      }     
   }

   showDetails(countryName):Observable<Country>{
     const url=`${this.restCountryEndPoint}/name/${countryName}`;
    return this.http.get<Country>(url).pipe(map(this.transformData.bind(this)));
   }

}
