package com.stackroute.favouriteservice.controller;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.favouriteservice.domain.Country;
import com.stackroute.favouriteservice.exception.CountryAlreadyExistsException;
import com.stackroute.favouriteservice.exception.CountryNotFoundException;
import com.stackroute.favouriteservice.service.CountryService;

import io.jsonwebtoken.Jwts;

@RestController
@RequestMapping(path = "/rest/v2")
@CrossOrigin
public class CountryController {
	
	private CountryService countryService;
	
	@Autowired
	public CountryController(CountryService countryService)
	{
		super();
		this.countryService = countryService; 
	}
	
	@PostMapping(path="/country")
	public ResponseEntity<?> saveNewCountry(@RequestBody final Country country,final ServletRequest req,final ServletResponse res) {
		ResponseEntity<?> responseEntity;		
		try {
			final HttpServletRequest request=(HttpServletRequest) req;
			final String authHeader=request.getHeader("authorization");
			final String token=authHeader.substring(7);
			String userId=Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
			country.setUserId(userId);
			countryService.saveCountry(country);
			responseEntity = new ResponseEntity<Country>(country, HttpStatus.CREATED);
		} 
		catch (CountryAlreadyExistsException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.CONFLICT);
		}
		return responseEntity;
		
	}
	
	@PutMapping
	public ResponseEntity<?> updateCountry(@RequestBody Country country) {
		ResponseEntity<?> responseEntity;
		try {
			final Country fetchedCountry=countryService.updateCountry(country);
			responseEntity=new ResponseEntity<Country>(fetchedCountry, HttpStatus.OK);
		} 
		catch (CountryNotFoundException e) {
			responseEntity=new ResponseEntity<String>("{\"message\": \""+e.getMessage()+"\"}", HttpStatus.CONFLICT);
		}
		return responseEntity;		
	}
	
	@DeleteMapping(path = "/{id}")
	public ResponseEntity<?> deleteCountryById(@PathVariable("id") final int id) {
		ResponseEntity<?> responseEntity;
		try {
			countryService.deleteCountryById(id);
			responseEntity=new ResponseEntity<String>("country deleted successfully", HttpStatus.OK);
		} 
		catch (CountryNotFoundException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.NOT_FOUND);
		}		
		return responseEntity;
	}
	
	@GetMapping(path = "/{id}")
	public ResponseEntity<?> fetchCountryById(@PathVariable("id") final int id) {
		ResponseEntity<?> responseEntity;
		Country country=null;
		try {
			country = countryService.getCountryById(id);
			responseEntity = new ResponseEntity<Country>(country, HttpStatus.OK);
		} 
		catch (CountryNotFoundException e) {
			responseEntity = new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}		
		return responseEntity;
	}
	
	@GetMapping
	public ResponseEntity<List<Country>> fetchAllCountries(final ServletRequest req,final ServletResponse res){
		final HttpServletRequest request=(HttpServletRequest) req;
		final String authHeader=request.getHeader("authorization");
		final String token=authHeader.substring(7);
		String userId=Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		return new ResponseEntity<List<Country>>(countryService.getAllCountries(userId),HttpStatus.OK);
	}

	
}
