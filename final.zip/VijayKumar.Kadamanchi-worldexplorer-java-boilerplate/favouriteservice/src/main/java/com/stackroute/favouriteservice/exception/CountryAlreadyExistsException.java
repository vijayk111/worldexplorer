package com.stackroute.favouriteservice.exception;

@SuppressWarnings("serial")
public class CountryAlreadyExistsException extends Exception {
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CountryAlreadyExistsException(String message) {
		super(message);
		this.message = message;
	}

	@Override
	public String toString() {
		return "CountryAlreadyExistsException [message=" + message + "]";
	}
	
}
