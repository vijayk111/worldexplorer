package com.stackroute.favouriteservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.favouriteservice.domain.Country;

public interface CountryRepository extends JpaRepository<Country, Integer> {	
	
	List<Country> findByUserId(String userId);
	
	Optional<Country> findByUserIdAndName(String userId, String Name);
	
}
