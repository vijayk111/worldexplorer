cd favouriteservice
source ./env-variable.sh
cd ..
cd userservice
source ./env-variable.sh
cd ..
