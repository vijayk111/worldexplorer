import { Component, Input } from '@angular/core';
import { AuthenticationService } from './modules/authentication/authentication.service';
import { Router } from '@angular/router';
import * as jwt_decode from 'jwt-decode';
import { FlexLayoutModule } from '@angular/flex-layout';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {  
  userId:string;
  token:string;
  public show:boolean = false;
  title = 'WorldExplorerUI';
 

  constructor(private authService:AuthenticationService,private routes:Router){

  }

  ngOnInit() {
   
  }


  logout(){
    this.authService.deleteToken();
    this.routes.navigate(['/login']);
  }

  isLoggedIn():boolean{
    this.token=this.authService.getToken();
   if(this.token==null){
      return false;
    }
    const decoded=jwt_decode(this.token);
    this.userId=decoded.sub;

    return true;
  }   

}
