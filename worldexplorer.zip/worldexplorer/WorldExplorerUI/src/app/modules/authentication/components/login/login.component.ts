import { Component, OnInit, Output } from '@angular/core';
import { User } from '../../user.model';
import { AuthenticationService } from '../../authentication.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'authentication-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  newUser:User;
 


  constructor(private authService:AuthenticationService,private router:Router,private snackbar:MatSnackBar) { 
    this.newUser=new User();
  }

  ngOnInit() {
  }

  loginUser(){
   
    this.authService.loginUser(this.newUser).subscribe(
      (data)=>{
        console.log("Successfully Logged In!");
      
        if(data['token']){
          this.authService.setToken(data['token']);
          console.log('token',data['token']);
          this.router.navigate(['/countries/allcountries']);
        } 
      },
    (error:HttpErrorResponse)=>{
      this.snackbar.open("Invalid credentials",'',{duration:2000});
    });

}
}
