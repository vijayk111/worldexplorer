export class User{
    firstName:string;
    lastName:string;
    userId:string;
    password:string;
}