import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Country } from '../../country.model';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CountryDialogComponent } from '../country-dialog/country-dialog.component';


@Component({
  selector: 'country-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
  @Input()
  country:Country;

  @Input()
  inFavourites:boolean;

  @Output()
  addFav=new EventEmitter();

  @Output()
  deleteFav=new EventEmitter();

  constructor(private dialog:MatDialog) {

   }

  ngOnInit() {
  }

  addFavList(){
    this.addFav.emit(this.country);
  }

  deleteFavList(){
    this.deleteFav.emit(this.country);

  }

  updateFromFavList(actionType){
    console.log("Country is getting updated");
    let dialogRef=this.dialog.open(CountryDialogComponent,{
      width:'400px',
      data:{ obj:this.country,actionType:actionType  }

    });
    console.log("Open dialog");
    dialogRef.afterClosed().subscribe(result=>{
      console.log("Dialog is closed");
    });
    
  }

  

}
