import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { RestcountriesComponent } from './components/restcountries/restcountries.component';
import { ContainerComponent } from './components/container/container.component';
import { FavouritesComponent } from './components/favourites/favourites.component';
import { CountryDialogComponent } from './components/country-dialog/country-dialog.component';
import { SearchComponent } from './components/search/search.component';
import { CountryService } from './country.service';
import { MatButtonModule,MatButton } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import {MatDialogModule} from '@angular/material/dialog';
import { MatCardModule } from '@angular/material/card';
import { TokenInterceptor } from './interceptor.service';
import { CountryRouterModule } from './country-router.module';
import { SelectCountryComponent } from './components/select-country/select-country.component';
import {MatDividerModule} from '@angular/material/divider';
import {MatTableModule} from '@angular/material/table';


@NgModule({
  declarations: [ThumbnailComponent, RestcountriesComponent, ContainerComponent,
     FavouritesComponent, CountryDialogComponent, SearchComponent, SelectCountryComponent],
  imports: [
    CommonModule,HttpClientModule, CountryRouterModule,
    MatCardModule,MatButtonModule,MatSnackBarModule,MatInputModule,FormsModule,
    MatDialogModule,MatDividerModule,MatTableModule
  ],
  providers:[CountryService],
  exports:[ThumbnailComponent, RestcountriesComponent, ContainerComponent,
     FavouritesComponent, CountryDialogComponent, SearchComponent],
     entryComponents:[CountryDialogComponent]
})
export class CountryModule { }
