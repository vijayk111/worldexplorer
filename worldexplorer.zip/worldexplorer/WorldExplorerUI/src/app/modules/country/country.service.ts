import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Country } from './country.model';
import { AuthenticationService } from '../authentication/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  restCountryEndPoint:string;
  springEndPoint:string;

  constructor(private http:HttpClient,private authService:AuthenticationService) {
    this.restCountryEndPoint='https://restcountries.eu/rest/v2';
    this.springEndPoint='http://localhost:8086/api/v1/favouriteservice';

   }

   getCountries():Observable<Array<Country>>{
     return this.http.get(this.restCountryEndPoint+"/all").pipe(map(this.transformData.bind(this)));
     }

     transformData(countries):Array<Country>{
       return countries.map(country=> {
         let coun:Country=new Country();
         coun.name=country['name'];
         coun.capital=country['capital'];
         coun.region=country['region'];
         coun.subregion=country['subregion'];
        coun.population=country['population'];
        coun.flag=country['flag'];

        return coun;
       });

     }

     addCountryToFavourites(country){
      return this.http.post(this.springEndPoint+"/country",country,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
    }

    updateComments(country:Country){
      const url=`${this.springEndPoint}/${country.id}`;
      return this.http.put(url,country,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
     }

     deleteFromFavourites(country:Country){
      const url=`${this.springEndPoint}/${country.id}`;
      return this.http.delete(url,{ headers:{  Authorization: `Bearer ${this.authService.getToken()}` },params:{responseType:"text"}});
    }

    getCountriesFromFavourites():Observable<Array<Country>>{
      return this.http.get<Array<Country>>(this.springEndPoint,{ headers: {  Authorization: `Bearer ${this.authService.getToken()}` } });
    }

    searchCountries(searchKey:string):Observable<Array<Country>>{
      if(searchKey.length>0){
        const url=`${this.restCountryEndPoint}/name/${searchKey}`;
        console.log(url);
        return this.http.get<Array<Country>>(url);
  
      }

     
   }

   showDetails(countryName):Observable<Country>{
     const url=`${this.restCountryEndPoint}/name/${countryName}`;
    return this.http.get<Country>(url).pipe(map(this.transformData.bind(this)));
   }

}
