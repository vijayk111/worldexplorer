package com.stackroute.favouriteservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "country")
public class Country {
	
	@Id
	@Column(name = "id")
	private int id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "capital")
	private String capital;
	
	@Column(name = "region")
	private String region;
	
	@Column(name = "callingcode")
	private int callingcode;
	
	@Column(name = "poster_path")
	private String poster_path;
	
	@Column(name = "comment")
	private String comment;

	@Column(name = "userId")
	private String userId;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
	public int getCallingcode() {
		return callingcode;
	}

	public void setCallingcode(int callingcode) {
		this.callingcode = callingcode;
	}

	public String getPoster_path() {
		return poster_path;
	}

	public void setPoster_path(String poster_path) {
		this.poster_path = poster_path;
	}

	public Country(int id, String name, String capital, String region, int callingcode,
			String poster_path, String comment, String userId) {
		super();
		this.id = id;
		this.name = name;
		this.capital = capital;
		this.region = region;
		this.callingcode = callingcode;
		this.poster_path = poster_path;
		this.comment = comment;
		this.userId = userId;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Country(){}
	
}
