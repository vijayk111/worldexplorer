package com.stackroute.favouriteservice.service;

import java.util.List;

import com.stackroute.favouriteservice.domain.Country;
import com.stackroute.favouriteservice.exception.CountryAlreadyExistsException;
import com.stackroute.favouriteservice.exception.CountryNotFoundException;

public interface CountryService {
	
	boolean saveCountry(Country country) throws CountryAlreadyExistsException;

	Country updateCountry(Country country) throws CountryNotFoundException;

	boolean deleteCountryById(int id) throws CountryNotFoundException;

	Country getCountryById(int id) throws CountryNotFoundException;

	List<Country> getAllCountries();
}
