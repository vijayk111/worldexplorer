package com.stackroute.favouriteservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.favouriteservice.domain.Country;
import com.stackroute.favouriteservice.exception.CountryAlreadyExistsException;
import com.stackroute.favouriteservice.exception.CountryNotFoundException;
import com.stackroute.favouriteservice.repository.CountryRepository;

@Service
public class CountryServiceImpl implements CountryService{
	
	public final transient CountryRepository countryRepo;
	
	@Autowired
	public CountryServiceImpl(CountryRepository countryRepo){
		super();
		this.countryRepo = countryRepo;
	}
	
	/* add country to database or throws exception if country name already exists*/
	@Override
	public boolean saveCountry(Country country) throws CountryAlreadyExistsException {
		final Optional<Country> object=countryRepo.findById(country.getId());
		if(object.isPresent())
		{
			throw new CountryAlreadyExistsException("Could not save country , country already exits");
		}
		countryRepo.save(country);
		return true;
	}
	
	/* update country name or throws exception if country name not found */
	@Override
	public Country updateCountry(Country country) throws CountryNotFoundException {
		final Country updateCountry=countryRepo.findById(country.getId()).orElse(null);
		if (updateCountry == null) {
			throw new CountryNotFoundException("Could not update. Country not found");
		}
		updateCountry.setComment(country.getComment());
		countryRepo.save(updateCountry);
		return updateCountry;
	}

	/* delete country name or throws exception if country name not found */
	@Override
	public boolean deleteCountryById(int id) throws CountryNotFoundException {
		final Country country=countryRepo.findById(id).orElse(null);
		if (country == null) {
			throw new CountryNotFoundException("Could not delete. Country not found");
		}
		countryRepo.delete(country);
		return true;
	}

	/* get country by searching country id or throws exception if country name not found */
	@Override
	public Country getCountryById(int id) throws CountryNotFoundException {
		final Country country = countryRepo.findById(id).get();
		if (country == null) {
			throw new CountryNotFoundException("Country not found");
		}
		return country;
	}

	/* get all countries list from database*/
	@Override
	public List<Country> getAllCountries() {
		return countryRepo.findAll();
	}

}
