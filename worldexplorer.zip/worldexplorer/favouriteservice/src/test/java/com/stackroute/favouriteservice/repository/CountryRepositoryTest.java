package com.stackroute.favouriteservice.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.favouriteservice.domain.Country;

import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class CountryRepositoryTest {
	
	@Autowired
	private transient CountryRepository countryRepository;

	public void setMovieRepository(CountryRepository countryRepository) {
		this.countryRepository = countryRepository;
	}
	
	@Test
	public void testSaveCountry() throws Exception {
		countryRepository.save(new Country(1, "India", "Delhi", "Asia", 91, "https://restcountries.eu/data/ind.svg", "INDIA", "abc"));
		final Country country = countryRepository.getOne(1);
		assertThat(country.getId()).isEqualTo(1);
	}
	
	@Test
	public void testUpdateCountry() throws Exception {
		countryRepository.save(new Country(1, "India", "Delhi", "Asia", 91, "https://restcountries.eu/data/ind.svg", "INDIA", "abc"));
		final Country country = countryRepository.getOne(1);
		assertEquals("India", country.getName());
		country.setComment("India");
		countryRepository.save(country);
		final Country tempCountry = countryRepository.getOne(1);
		assertEquals("INDIA", tempCountry.getComment());
	}
	
	@Test
	public void testDeleteCountry() throws Exception {
		countryRepository.save(new Country(1, "India", "Delhi", "Asia", 91, "https://restcountries.eu/data/ind.svg", "INDIA", "abc"));
		final Country country = countryRepository.getOne(1);
		assertEquals("India", country.getName());
		countryRepository.delete(country);
		assertEquals(Optional.empty(), countryRepository.findById(1));
	}
	
	@Test
	public void testGetCountry() throws Exception {
		countryRepository.save(new Country(1, "India", "Delhi", "Asia", 91, "https://restcountries.eu/data/ind.svg", "INDIA", "abc"));
		final Country country = countryRepository.getOne(1);
		assertEquals("India", country.getName());
	}
	
	@Test
	public void testGetMyCountries() throws Exception {
		countryRepository.save(new Country(1, "India", "Delhi", "Asia", 91, "https://restcountries.eu/data/ind.svg", "INDIA", "abc"));
		countryRepository.save(new Country(2, "United States", "New York", "North America", 1, "https://restcountries.eu/data/usa.svg", "USA", "abc"));
		final List<Country> countries = countryRepository.findAll();
		assertEquals("India", countries.get(0).getName());
	}
	
}
