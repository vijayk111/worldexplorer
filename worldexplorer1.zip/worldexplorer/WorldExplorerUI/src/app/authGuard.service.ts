import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthenticationService } from './modules/authentication/authentication.service';

@Injectable()
export class AuthguardService implements CanActivate{
constructor(private route:Router,private authService:AuthenticationService){}

canActivate(){
    if(!this.authService.isTokenExpired()){
        console.log('user authorized!');
        return true;
    }
    this.route.navigate(['/login']);
    return false;
}

}