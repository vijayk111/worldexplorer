import { Component, OnInit } from '@angular/core';
import { CountryService } from '../../country.service';
import { Country } from '../../country.model';

@Component({
  selector: 'country-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  countries:Array<Country>;
  constructor(private countryService:CountryService) { 
    this.countries=[];
  }

  ngOnInit() {
  }

  onEnter(searchKey:string){
    this.countryService.searchCountries(searchKey).subscribe(
      (countries)=>{
       this.countries.push(...countries);
      });
  }

 

}
