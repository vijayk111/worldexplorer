export class Country{
    id:number;
    name:string;
    capital:string;
    region:string;
    callingCodes:number;
    flag:string;
    comments:string;
    userId:string;    
}