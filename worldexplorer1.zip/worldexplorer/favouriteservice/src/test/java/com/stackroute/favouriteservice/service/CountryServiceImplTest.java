package com.stackroute.favouriteservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.stackroute.favouriteservice.domain.Country;
import com.stackroute.favouriteservice.exception.CountryAlreadyExistsException;
import com.stackroute.favouriteservice.exception.CountryNotFoundException;
import com.stackroute.favouriteservice.repository.CountryRepository;

public class CountryServiceImplTest {
	
	@Mock
	CountryRepository countryRepository;
	
	private transient Country country;
	
	@InjectMocks
	private transient CountryServiceImpl countryServiceImpl;
	
	transient Optional<Country> options;
	
	@Before
	public void setupMock() {
		MockitoAnnotations.initMocks(this);
		country = new Country(1, "India", "Delhi", "Asia", "91", "https://restcountries.eu/data/ind.svg", "INDIA", "abc");
		options = Optional.of(country);
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("JpaRepository creation failed: use @InjectMocks on movieServiceImpl", country);
	}
	
	@Test
	public void testSaveCountrySuccess() throws CountryAlreadyExistsException {
		when(countryRepository.save(country)).thenReturn(country);
		final boolean flag = countryServiceImpl.saveCountry(country);
		assertTrue("saving movie failed", flag);
		verify(countryRepository, times(1)).save(country);
	}
	
	@Test(expected = CountryAlreadyExistsException.class)
	public void testSaveCountryFailure() throws CountryAlreadyExistsException {
		when(countryRepository.findById(1)).thenReturn(options);
		when(countryRepository.save(country)).thenReturn(country);
		final boolean flag = countryServiceImpl.saveCountry(country);
		assertFalse("saving movie failed", flag);
		verify(countryRepository, times(1)).findById(country.getId());
	}

	@Test
	public void testUpdateCountry() throws CountryNotFoundException {
		when(countryRepository.findById(1)).thenReturn(options);
		when(countryRepository.save(country)).thenReturn(country);
		country.setComments("INDIA");
		final Country country1 = countryServiceImpl.updateCountry(country);
		assertEquals("updaing country failed", country.getComments(), country1.getComments());
		verify(countryRepository, times(1)).save(country);
		verify(countryRepository, times(1)).findById(country.getId());
	}
	
	@Test
	public void testDeleteCountryById() throws CountryNotFoundException {
		when(countryRepository.findById(1)).thenReturn(options);
		doNothing().when(countryRepository).delete(country);
		country.setComments("INDIA");
		final boolean flag = countryServiceImpl.deleteCountryById(1);
		assertTrue("deleting country failed", flag);
		verify(countryRepository, times(1)).delete(country);
		verify(countryRepository, times(1)).findById(country.getId());
	}

	@Test
	public void testGetCountryById() throws CountryNotFoundException {
		when(countryRepository.findById(1)).thenReturn(options);
		final Country country1 = countryServiceImpl.getCountryById(1);
		assertEquals("fetching country by id failed", country, country1);
		verify(countryRepository, times(1)).findById(country.getId());
	}

	@Test
	public void testGetAllCountries() throws CountryNotFoundException {
		final List<Country> countries = new ArrayList<>();
		countries.add(country);
		when(countryRepository.findAll()).thenReturn(countries);
		final List<Country> countries1 = countryServiceImpl.getAllCountries("abc");
		assertEquals(countries, countries1);
		verify(countryRepository, times(1)).findAll();
	}
	
}
