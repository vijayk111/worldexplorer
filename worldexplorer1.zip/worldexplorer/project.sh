cd favouriteservice
source ./env-variable.sh
cd ..

