package com.stackroute.userservice.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.stackroute.userservice.domain.User;
import com.stackroute.userservice.exception.UserAlreadyExistsException;
import com.stackroute.userservice.exception.UserNotFoundException;
import com.stackroute.userservice.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;

	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	public boolean saveUser(User user) throws UserAlreadyExistsException {
		Optional<User> u1 = userRepository.findById(user.getUserId());
		if (u1.isPresent()) {
			throw new UserAlreadyExistsException("User with this id already exists");
		}
		userRepository.save(user);
		return true;
	}

	public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException {
		User user = userRepository.findByUserIdAndPassword(userId, password);
		if (user == null) {
			throw new UserNotFoundException("userid or password incorrect");
		}
		return user;
	}

}
